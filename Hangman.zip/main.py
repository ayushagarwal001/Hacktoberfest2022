import random
from replit import clear

logo = ''' 
 _                                             
| |                                            
| |__   __ _ _ __   __ _ _ __ ___   __ _ _ __  
| '_ \ / _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
| | | | (_| | | | | (_| | | | | | | (_| | | | |
|_| |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                    __/ |                      
                   |___/    '''


stages = ['''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''', '''
  +---+
  |   |
      |
      |
      |
      |
=========
''']

word_list = ["aardvark", "baboon", "camel", "hire", "almond", "bottle", "drained", "electronic", "failiure", "hairdrier", "impudent", "junior", "kelvin", "lasergun", "monalisa", "netflix", "opaque", "peach", "quest", "roarrr", "silkworm", "tinglyy", "unicorn", "vulgar", "witch", "xmas", "yourname", "zzzz"]
chosen_word = random.choice(word_list)
print(logo)
display = []
print(f'Pssst, the solution is ')
for word in chosen_word:
  display += "_"
print(display)

def fill_display():
  for n in range(len(display)):
    if display[n] == '_'and lives != 0:
      return 0

lives = 6
print(f"Lives remaining {lives}")

while fill_display() == 0:
  guess = input("Guess a letter: ").lower()
  clear()
  if guess in display:
    print("You have already guessed this letter")
  for n in range(0, len(chosen_word)):
    if chosen_word[n] == guess:
      display[n] = guess    
  
  if guess not in chosen_word:
    print("You typed the wrong letter, you lost a life")
    lives -= 1
    print(f"Lives remaining {lives}")
    if lives == 0:
      print("You Lose")

  if '_' not in display:
    print("Congratulations, You Win!")
  
  print(stages[int(lives)])

  print(display)
  

